# Hello World

This is an example of how to publish a python module to PyPI

## Usage

```python
from helloworld import say_hello

# Generate "Hello, World"
say_hello()

# Generate "Hello Everybody"

say_hello("Everybody")
```



